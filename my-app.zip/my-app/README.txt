If there is any confusions about anything as the program opens up, it's meant to represent what it would look like on a mobile device. In order to advance
through the app, just click anywhere where a screen would be to advance into the app. Clicking on icons also brings up more information related to the text below
the icon.

Everything works to deliver a minimum viable product, besides the fact that the image for the information on Covid-19 seemingly has an issue loading.
Nontheless, the app function similarly to my intended design, and is really only missing all the programming to make it function like a final product.