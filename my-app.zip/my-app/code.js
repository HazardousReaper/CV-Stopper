onEvent("Introduction", "click", function(event) {
  setScreen ("Menu_Screen");
});
onEvent("return", "click", function(event) {
  setScreen ("Main_Screen");
});
onEvent("corona_icon", "click", function(event) {
  setScreen ("Covid-19_Info");
});
onEvent("ReturnToMenu", "click", function(event) {
  setScreen("Menu_Screen");
});
onEvent("map_icon", "click", function(event) {
  setScreen("GlobalMap");
});
onEvent("GoBack", "click", function(event) {
  setScreen ("Menu_Screen");
});
onEvent("empathy_icon", "click", function(event) {
  setScreen ("DonationScreen");
});
onEvent("Menu", "click", function(event) {
  setScreen("Menu_Screen");
});
onEvent("protection_icon", "click", function(event) {
  setScreen("ProtectionScreen");
});
onEvent("Next", "click", function(event) {
  setScreen ("ProtectionScreen2");
});
onEvent("Back", "click", function(event) {
  setScreen ("Menu_Screen");
});
onEvent("GoToMenu", "click", function(event) {
  setScreen ("Menu_Screen");
});
onEvent("ReturnBack", "click", function(event) {
  setScreen ("ProtectionScreen");
});
onEvent("CPU_Icon", "click", function(event) {
  setScreen ("DedicateYourself");
});
onEvent("Menuu", "click", function(event) {
  setScreen("Menu_Screen");
});
